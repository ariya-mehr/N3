# -*- coding: utf-8 -*-
"""Stage 2 title/abstract screening data — one dict per GDR record (GDR001-GDR040).

All decisions are made ONLY from title/abstract-level evidence contained in
Bibliography_Final_Stage1.csv (plus the two publisher-page abstract checks for
GDR005 and GDR035 documented in the source-evidence note).
"""
import csv, os

S1 = os.path.join(os.path.dirname(__file__), "..", "03_STAGE1A_FINAL_AUTHORITATIVE")
BIB = os.path.join(S1, "Bibliography_Final_Stage1.csv")
OUT = os.path.dirname(os.path.abspath(__file__))

def load_bib():
    rows = {}
    with open(BIB, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            if r.get("Paper_ID"):
                rows[r["Paper_ID"]] = r
    return rows

# decision table: id -> dict of screening fields (evidence strings written below)
D = {}

def dec(i, cls, decision, ga, ex, dd, mmr, te, ae, url, fam, famnote, ftreq, fta, ckpt, unc, tags, notes, excode=""):
    D[i] = dict(Study_Relevance_Class=cls, Screening_Decision=decision,
                GaN_HEMT_Confirmed=ga, Experimental_Data_Confirmed=ex,
                Direct_Dynamic_RON_Evidence=dd, Measurement_Method_Relevance=mmr,
                Title_Evidence=te, Abstract_Evidence=ae, Evidence_Source_URL=url,
                Report_Family_ID=fam, Family_Relationship_Note=famnote,
                Full_Text_Required=ftreq, Full_Text_Access_Status_As_Known=fta,
                Full_Text_Checkpoints=ckpt, Screening_Uncertainty=unc,
                Secondary_Topic_Tags=tags, Reviewer_Notes=notes, Exclusion_Reason_Code=excode)

# ---------------- GDR001 Measurement-Method ----------------
dec("GDR001", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a dynamic-RON extraction/measurement technique compared under soft and hard switching.",
    "Title: 'Extraction of Dynamic On-Resistance in GaN Transistors: Under Soft- and Hard-Switching Conditions'.",
    "Abstract: reports a measurement technique and experimental comparison of commercial GaN transistor dynamic RDS(on) under soft- and hard-switching conditions.",
    "https://doi.org/10.1109/CSICS.2011.6062461", "", "",
    "Yes", "Publisher DOI landing page/metadata visible; full paper access not assessed",
    "Confirm measured device types, stress conditions, measurement timing/window parameters, and reporting completeness.",
    "Low: abstract explicitly states measurement technique with experimental comparison on GaN transistors.",
    "soft switching; hard switching; measurement technique",
    "RF-flag none. Abstract-level decision only; no full-text eligibility claimed.")

# ---------------- GDR002 (RF01) ----------------
dec("GDR002", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; dynamic-RON transients are the experimental endpoint.",
    "Title: 'Mechanisms responsible for dynamic ON-resistance in GaN high-voltage HEMTs'.",
    "Abstract: experimental dynamic RON transients over a wide time range; discusses detrapping mechanisms.",
    "https://doi.org/10.1109/ISPSD.2012.6229089", "RF01",
    "RF01 (GDR002/003/004): related report family, shared authors and evolving method; independence unresolved.",
    "Yes", "Researcher/publication metadata and DOI visible; full text not confirmed",
    "Compare full texts with GDR003/GDR004 for device identifiers, stress protocols and dataset overlap.",
    "Low: abstract explicitly reports experimental dynamic-RON transients on GaN HV HEMTs.",
    "detrapping; transients; mechanisms",
    "Retained as distinct report record; no duplicate decision made.")

# ---------------- GDR003 (RF01) ----------------
dec("GDR003", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; dynamic-RON under high-power stress is the endpoint.",
    "Title: 'Impact of high-power stress on dynamic ON-resistance of high-voltage GaN HEMTs'.",
    "Abstract: experimental study of high-power stress effects on dynamic RON with transient measurements after OFF-to-ON switching.",
    "https://www.sciencedirect.com/science/article/abs/pii/S0026271412004118", "RF01",
    "RF01 (GDR002/003/004): related report family, shared authors and evolving method; independence unresolved.",
    "Yes", "ScienceDirect abstract page visible; full text not accessed",
    "Compare full texts with GDR002/GDR004 for device/sample overlap and stress protocol differences.",
    "Low: abstract explicitly reports experimental dynamic-RON measurements on GaN HV HEMTs.",
    "high-power stress; trapping; transients",
    "Retained as distinct report record; no duplicate decision made.")

# ---------------- GDR004 (RF01) ----------------
dec("GDR004", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a time-resolved dynamic-RON methodology for HV GaN FETs.",
    "Title: 'Methodology for the Study of Dynamic ON-Resistance in High-Voltage GaN Field-Effect Transistors'.",
    "Abstract: introduces a time-resolved dynamic RON methodology and reports experimental transients under varied bias and temperature.",
    "https://doi.org/10.1109/TED.2013.2274477", "RF01",
    "RF01 (GDR002/003/004): related report family, shared authors and evolving method; independence unresolved.",
    "Yes", "Author repository / publisher metadata visible; no full-text screening performed",
    "Compare full texts with GDR002/GDR003; extract methodology parameters and reporting completeness.",
    "Low: abstract explicitly reports a dynamic-RON methodology with experimental transients.",
    "time-resolved; measurement protocol; bias/temperature",
    "Retained as distinct report record; no duplicate decision made.")

# ---------------- GDR005 (special) ----------------
dec("GDR005", "Experimental Measurement Method / Instrumentation / Protocol", "Unclear", "Yes", "Yes", "Unclear",
    "Method paper on dynamic-RON voltage-clamp measurement; GaN-specific validation not established at abstract level.",
    "Title: 'A Fast Voltage Clamp Circuit for the Accurate Measurement of the Dynamic ON-Resistance of Power Transistors' - no GaN mention in title.",
    "Publisher abstract (OpenAlex reconstruction of IEEE TIE record): presents a novel voltage-clamp circuit for accurate ON-state voltage measurement and motivates it by AlGaN/GaN current collapse, but validation is shown via 'measurements on a 2-MHz inverted buck converter' without naming the transistor technology used.",
    "https://ieeexplore.ieee.org/document/6880783", "", "",
    "Yes", "Publisher metadata/abstract visible; OpenAlex abstract reconstruction consulted 2026-11-17; full text not accessed",
    "At full text: identify which transistor technology was used in the validation measurements (GaN HEMT or other, e.g., Si/SiC MOSFET) and whether dynamic-RON data on GaN are reported.",
    "Medium: dynamic-RON method validated, but the abstract does not establish that the validation devices were GaN HEMTs; GaN appears only as motivation.",
    "voltage clamp; measurement circuit; current collapse motivation",
    "Per handoff instruction, NOT auto-included. GaN_HEMT_Confirmed=Unclear because the abstract mentions AlGaN/GaN only as motivation; validation device technology unknown.")

# ---------------- GDR006 ----------------
dec("GDR006", "Direct Dynamic-RON Experimental Measurement", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; direct dynamic-RON comparison of device types is the study.",
    "Title: 'Investigation of the Dynamic On-State Resistance of 600 V Normally-Off and Normally-On GaN HEMTs'.",
    "Abstract: experimental comparison of dynamic on-state resistance in normally-off and normally-on 600-V GaN HEMTs.",
    "https://doi.org/10.1109/TIA.2016.2585564", "", "",
    "Yes", "DOI/publisher metadata visible; full text not reviewed",
    "Extract device types, stress conditions, measurement window and timing parameters.",
    "Low: abstract explicitly reports experimental dynamic-RON characterization of GaN HEMTs.",
    "600 V; normally-off; normally-on; device comparison",
    "Abstract-level decision only.")

# ---------------- GDR007 (RF02) ----------------
dec("GDR007", "Direct Dynamic-RON Experimental Measurement", "Include", "Yes", "Yes", "Yes",
    "Study includes characterization of GaN HEMT dynamic RDS(on); not primarily a method-development report per Stage 1 classification.",
    "Title: 'GaN-HEMT dynamic ON-state resistance characterisation and modelling'.",
    "Abstract: experimental circuit characterization of commercial GaN HEMT dynamic RDS(on) across trapping and detrapping conditions; related extended journal report GDR012.",
    "https://doi.org/10.1109/COMPEL.2016.7556732", "RF02",
    "RF02 (GDR007/012): conference-to-journal relationship; journal report describes initial characterization in this conference report; independence unresolved.",
    "Yes", "DOI and publisher metadata visible; full text not reviewed",
    "Compare full texts with GDR012 (devices, datasets, analyses) before any independence statement.",
    "Low: abstract explicitly reports experimental dynamic-RDS(on) characterization on commercial GaN HEMTs.",
    "characterization; modelling; trapping/detrapping",
    "Conference record of RF02 pair; retained separately from GDR012.")

# ---------------- GDR008 ----------------
dec("GDR008", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a dynamic-RON characterization technique evaluating thermal and off-state stress on GaN switches.",
    "Title: 'Dynamic RON Characterization Technique for the Evaluation of Thermal and Off-State Voltage Stress of GaN Switches'.",
    "Abstract: describes experimental dynamic-RON characterization of 600-V GaN switches over blocking voltage, switching frequency, and temperature.",
    "https://doi.org/10.1109/TPEL.2017.2710281", "", "",
    "Yes", "DOI and abstract metadata visible; Crossref-verified publication metadata (2018 journal year)",
    "Extract characterization-technique parameters, stress ranges, and measurement timing details.",
    "Low: abstract explicitly reports a dynamic-RON characterization technique with experimental GaN data.",
    "stress characterization; blocking voltage; frequency; temperature",
    "Abstract-level decision only.")

# ---------------- GDR009 (flagged) ----------------
dec("GDR009", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; dynamic-RON increase under hard switching is the experimental endpoint.",
    "Title: 'Evidence of Hot-Electron Effects During Hard Switching of AlGaN/GaN HEMTs'.",
    "IEEE abstract reports a special double-pulse setup that induces soft/hard switching while measuring ON-resistance, drain current and electroluminescence; hard-switching caused a measurable dynamic-RON increase attributed to hot electrons.",
    "https://ieeexplore.ieee.org/document/8000404/", "", "",
    "Yes", "IEEE Xplore metadata/abstract visible; full text not screened (Stage 1A flag)",
    "Extract DPT setup parameters, stress conditions, measurement delay/timing, and hot-electron evidence chain at full text.",
    "Low on abstract evidence (Stage 1A verified author list and abstract); medium pending full text.",
    "hard switching; hot electrons; double-pulse; electroluminescence",
    "Handoff-flagged record: abstract-supported candidate pending full text; no full-text eligibility claimed.")

# ---------------- GDR010 (RF03) ----------------
dec("GDR010", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a standardized dynamic-RON measurement approach and metrics from low-voltage GaN HEMT measurements.",
    "Title: 'Developing a standardized method for measuring and quantifying dynamic on-state resistance via a survey of low voltage GaN HEMTs'.",
    "Abstract: introduces a controlled measurement approach and metrics based on low-voltage commercial GaN HEMT measurements; related journal survey GDR018, possible dataset overlap.",
    "https://doi.org/10.1109/APEC.2018.8341401", "RF03",
    "RF03 (GDR010/018): conference/journal report family, same author group; possible sample/data overlap; independence unresolved.",
    "Yes", "DOI and citation metadata visible; full text not reviewed",
    "Compare device sets, measurement data and methods with GDR018 across full texts.",
    "Low: abstract explicitly reports a standardized dynamic-RON measurement method with GaN HEMT data.",
    "standardized metrics; low-voltage GaN; conference record",
    "Conference record of RF03 pair; retained separately from GDR018.")

# ---------------- GDR011 ----------------
dec("GDR011", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a dynamic-RON measurement approach at MHz switching frequencies.",
    "Title: 'Measuring Dynamic On Resistance in GaN Transistors at MHz Frequencies'.",
    "Abstract: experimental dynamic on-resistance measurements at MHz switching frequencies.",
    "https://doi.org/10.1109/COMPEL.2018.8460051", "", "",
    "Yes", "Metadata and DOI visible; full paper access not assessed",
    "Extract measurement bandwidth/technique limits at MHz frequencies and reporting completeness.",
    "Low: title and abstract explicitly report dynamic-RON measurement on GaN transistors at MHz frequencies.",
    "MHz switching; measurement bandwidth",
    "Abstract-level decision only.")

# ---------------- GDR012 (RF02) ----------------
dec("GDR012", "Direct Dynamic-RON Experimental Measurement", "Include", "Yes", "Yes", "Yes",
    "Study reports dynamic-RDS(on) measurements and a validated behavioral model; not primarily method-development per Stage 1 classification.",
    "Title: 'Characterisation and Modeling of Gallium Nitride Power Semiconductor Devices Dynamic On-State Resistance'.",
    "Abstract: reports measurements of dynamic RDS(on) for commercial GaN HEMTs and a behavioral model validated against switching measurements.",
    "https://doi.org/10.1109/TPEL.2017.2730260", "RF02",
    "RF02 (GDR007/012): conference-to-journal relationship; authors state initial characterization in GDR007; likely extension, independence unresolved.",
    "Yes", "Institutional repository PDF metadata visible; full-text screening deferred",
    "Compare full texts with GDR007 (devices, data, analyses) before any independence statement.",
    "Low: abstract explicitly reports dynamic-RDS(on) measurements on commercial GaN HEMTs.",
    "characterization; behavioral modelling; commercial devices",
    "Journal record of RF02 pair; retained separately from GDR007.")

# ---------------- GDR013 ----------------
dec("GDR013", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a test circuit enabling controlled-stress GaN HEMT dynamic-RON characterization.",
    "Title: 'A Test Circuit for GaN HEMTs Dynamic Ron Characterization in Power Electronics Applications'.",
    "Abstract: experimental circuit permits controlled stress voltage/time and repeated switching pulses for GaN HEMT dynamic-RON characterization.",
    "https://doi.org/10.1109/JESTPE.2019.2912130", "", "",
    "Yes", "DOI metadata and abstract visible; full text not reviewed",
    "Extract circuit parameters, stress-control capability and measurement timing details.",
    "Low: abstract explicitly reports a dynamic-RON test circuit with GaN HEMT characterization.",
    "test circuit; stress control; repeated pulses",
    "Abstract-level decision only.")

# ---------------- GDR014 (author list unverified) ----------------
dec("GDR014", "Direct Dynamic-RON Experimental Measurement", "Include", "Yes", "Yes", "Yes",
    "Study evaluates temperature-dependent dynamic RDS(on) under DPT/MPT; not primarily method-development per Stage 1 classification.",
    "Title: 'Evaluation and Analysis of Temperature-dependent Dynamic RDS,ON of GaN Power Devices Considering High-Frequency Operation'.",
    "Abstract: experimental DPT/MPT evaluation of temperature-dependent dynamic RDS(on) at high frequency, including limitations of pulse protocols.",
    "https://doi.org/10.1109/JESTPE.2019.2947575", "", "",
    "Yes", "DOI metadata and abstract visible; full text not reviewed",
    "Extract temperature ranges, DPT/MPT parameters, pulse widths, and reported measurement-window settings.",
    "Low on abstract evidence; medium on metadata (author list unverified).",
    "temperature; high frequency; DPT; MPT; pulse-protocol limitations",
    "Stage 1A metadata caution: full author list not verified; retained pending verification; not corrected here.")

# ---------------- GDR015 ----------------
dec("GDR015", "Direct Dynamic-RON Experimental Measurement", "Include", "Yes", "Yes", "Yes",
    "Study reports controlled steady-state dynamic-RON measurements and contrasts them with DPT; includes characterization framework discussion.",
    "Title: 'Dynamic on-Resistance in GaN-on-Si HEMTs: Origins, Dependencies, and Future Characterization Frameworks'.",
    "Abstract: reports controlled steady-state dynamic-RON measurements and contrasts them with DPT; includes experimental data on operating dependencies.",
    "https://ieeexplore.ieee.org/document/8911415/", "", "",
    "Yes", "IEEE abstract and author-hosted full-text copy surfaced; no full-text screening performed",
    "Extract steady-state measurement protocol, dependencies reported, and DPT-contrast methodology.",
    "Low: abstract explicitly reports experimental steady-state dynamic-RON measurements on GaN-on-Si HEMTs.",
    "steady state; operating dependencies; characterization framework",
    "Abstract-level decision only.")

# ---------------- GDR016 ----------------
dec("GDR016", "Direct Dynamic-RON Experimental Measurement", "Include", "Yes", "Yes", "Yes",
    "Study measures dynamic-RON frequency dependence; not primarily method-development per Stage 1 classification.",
    "Title: 'The Impact of Multi-MHz Switching Frequencies on Dynamic On-Resistance in GaN-on-Si HEMTs'.",
    "Abstract: experimental steady-state measurements on a commercial GaN-on-Si HEMT across switching frequency up to multi-MHz.",
    "https://superlab.stanford.edu/publication/2020-07-01-Impact-MHz-DynamicRdson_Zulauf/index.html", "", "",
    "Yes", "Author lab page and paper metadata visible; full-text review deferred",
    "Extract frequency sweep range, measurement method, and steady-state vs pulsed conditions.",
    "Low: abstract explicitly reports experimental dynamic-RON measurements vs switching frequency.",
    "multi-MHz; switching frequency; steady state",
    "Abstract-level decision only.")

# ---------------- GDR017 ----------------
dec("GDR017", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is an accurate dynamic-RDS(on) extraction method under reverse and forward conduction.",
    "Title: 'Accurate Measurement of Dynamic on-State Resistances of GaN Devices under Reverse and Forward Conduction in High Frequency Power Converter'.",
    "Abstract: experimental comparison of dynamic RDS(on) extraction methods under reverse/forward conduction in a high-frequency converter.",
    "https://doi.org/10.1109/TPEL.2019.2961604", "", "",
    "Yes", "Open institutional repository record indicates CC BY; paper not reviewed in this stage",
    "Compare extraction methods, conduction-mode handling, and reporting completeness.",
    "Low: abstract explicitly reports comparison of dynamic-RDS(on) extraction methods with GaN device data.",
    "reverse conduction; forward conduction; high frequency; method comparison",
    "Abstract-level decision only.")

# ---------------- GDR018 (RF03) ----------------
dec("GDR018", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: journal survey develops normalized dynamic-RON metrics and measurement control across devices.",
    "Title: 'Quantifying Dynamic On-State Resistance of GaN HEMTs for Power Converter Design via a Survey of Low and High Voltage Devices'.",
    "Abstract: survey/measurement study across commercial low- and high-voltage GaN transistors proposing normalized metrics and discussing measurement control.",
    "https://www.osti.gov/biblio/1870981", "RF03",
    "RF03 (GDR010/018): journal extension of GDR010 conference method survey; possible dataset overlap; independence unresolved.",
    "Yes", "OSTI metadata/abstract visible; publisher full text not checked",
    "Compare device sets, measurement data and methods with GDR010 across full texts.",
    "Low: abstract explicitly reports dynamic-RON measurement survey with normalized metrics.",
    "measurement survey; normalized metrics; low/high voltage devices",
    "Journal record of RF03 pair; retained separately from GDR010.")

# ---------------- GDR019 ----------------
dec("GDR019", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a validated clamping-based dynamic-RON measurement setup under hard and soft switching.",
    "Title: 'Test Setup for Dynamic On-State Resistance Measurement of High- and Low-Voltage GaN-HEMTs under Hard and Soft Switching Operations'.",
    "Abstract: presents and validates clamping-based measurement of dynamic on-state resistance under hard and soft switching for high- and low-voltage devices.",
    "https://doi.org/10.1109/TIM.2020.2985186", "", "",
    "Yes", "IEEE metadata/abstract visible; title verified against IEEE Xplore",
    "Extract clamping technique parameters, validation device set, and timing/measurement-window reporting.",
    "Low: abstract explicitly reports a validated dynamic-RON test setup with GaN-HEMT measurements.",
    "clamping; hard/soft switching; high/low voltage",
    "GDR010 abstract cross-reference in authoritative bibliography now points to GDR018 (handoff correction); no relation to GDR019 is asserted here.")

# ---------------- GDR020 (author list unverified) ----------------
dec("GDR020", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a fast on-wafer dynamic-RDS(on) measurement system.",
    "Title: 'Fast System to measure the dynamic on-resistance of on-wafer 600 V normally off GaN HEMTs in hard-switching application conditions'.",
    "Abstract: experimental on-wafer dynamic-RDS(on) system using boost-converter-like operation and hard-switching conditions.",
    "https://digital-library.theiet.org/doi/full/10.1049/iet-pel.2019.1455", "", "",
    "Yes", "IET abstract and bibliographic metadata visible; full text not reviewed",
    "Extract measurement-system parameters, on-wafer setup, hard-switching conditions and timing.",
    "Low on abstract evidence; medium on metadata (author list unverified).",
    "on-wafer; fast measurement; hard switching; 600 V",
    "Stage 1A metadata caution: full author list not verified; retained pending verification.")

# ---------------- GDR021 (RF04, authors unverified) ----------------
dec("GDR021", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; dynamic RDSON under gamma irradiation is the experimental endpoint.",
    "Title: 'Impact of Gamma Radiation on Dynamic RDSON Characteristics in AlGaN/GaN Power HEMTs'.",
    "Abstract: experimental dynamic resistance measurements of commercial GaN HEMTs under gamma irradiation and different bias histories.",
    "https://doi.org/10.3390/ma12172760", "RF04",
    "RF04 (GDR021/024): related irradiation-study reports; retained as provisionally distinct studies, verify at full text.",
    "Yes", "Open-access publisher article listed; full text not reviewed",
    "At full text: compare with GDR024 for sample identities, dose, temperature protocol and data overlap; extract irradiation conditions and dynamic-RON measurement protocol.",
    "Low on abstract evidence; medium on metadata (author list unverified).",
    "gamma irradiation; dynamic RDSON; bias history",
    "RF04 kept separate from GDR024; no merge or duplicate decision.")

# ---------------- GDR022 ----------------
dec("GDR022", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; dynamic-RON degradation mechanism analysis is the endpoint.",
    "Title: 'Mechanism Analysis of Dynamic On-State Resistance Degradation for a Commercial GaN HEMT Using Double Pulse Test'.",
    "Abstract: experimental DPT and multi-pulse study of stress voltage, stress duration, and frequency effects on one commercial p-GaN HEMT.",
    "https://doi.org/10.3390/electronics10101202", "", "",
    "Yes", "Open-access publisher full-text page appears available; not reviewed for inclusion",
    "Extract DPT parameters, stress matrix, measurement timing, and mechanism-analysis evidence.",
    "Low: abstract explicitly reports experimental DPT dynamic-RON degradation study on a commercial GaN HEMT.",
    "double-pulse test; multi-pulse; stress voltage/duration/frequency; degradation",
    "Abstract-level decision only.")

# ---------------- GDR023 ----------------
dec("GDR023", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is an on-die DPT measurement apparatus for dynamic-RON.",
    "Title: 'Development of a Device for On-Die Double-Pulse Testing and Measurement of Dynamic On-Resistance of GaN HEMTs'.",
    "Abstract: builds and validates a probe-station-integrated on-die DPT tester; includes waveforms from experimental unpackaged GaN HEMTs.",
    "https://doi.org/10.15598/aeee.v19i4.4136", "", "",
    "Yes", "Open metadata and PDF surfaced; full-text screening deferred",
    "Extract on-die tester parameters, validation waveforms and measurement timing details.",
    "Low: abstract explicitly reports an on-die DPT dynamic-RON measurement device with GaN HEMT data.",
    "on-die DPT; probe station; unpackaged devices; measurement apparatus",
    "Abstract-level decision only.")

# ---------------- GDR024 (RF04, authors unverified) ----------------
dec("GDR024", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; temperature-dependent dynamic-RON after irradiation is the endpoint.",
    "Title: 'Temperature-Dependent Dynamic on Resistance in Gamma-Irradiated AlGaN/GaN Power HEMTs'.",
    "Abstract: experimental DPT and multi-pulse dynamic-RON tests after gamma irradiation at different temperatures and bias stress conditions.",
    "https://doi.org/10.3390/app122211578", "RF04",
    "RF04 (GDR021/024): related irradiation-study reports; retained as provisionally distinct studies, verify at full text.",
    "Yes", "Open-access publisher article listed; full text not reviewed",
    "At full text: compare with GDR021 for sample identities, dose, temperature protocol and data overlap; extract temperature/dose matrix.",
    "Low on abstract evidence; medium on metadata (author list unverified).",
    "gamma irradiation; temperature dependence; DPT; multi-pulse",
    "RF04 kept separate from GDR021; no merge or duplicate decision.")

# ---------------- GDR025 ----------------
dec("GDR025", "Direct Dynamic-RON Experimental Measurement", "Include", "Yes", "Yes", "Yes",
    "Study performs isothermal dynamic-RON characterization under operating conditions; Stage 1 class is Experimental Device/Mechanism Study.",
    "Title: 'Characterization of the Dynamic RON of 600 V GaN Switches under Operating Conditions'.",
    "Abstract: experimental isothermal characterization under operating conditions, varying blocking voltage, frequency, temperature, and measurement window.",
    "https://doi.org/10.3390/electronics12040943", "", "",
    "Yes", "Open-access publisher full-text page appears available; not reviewed",
    "Extract isothermal method, blocking voltage/frequency/temperature matrix, and measurement-window definitions.",
    "Low: abstract explicitly reports experimental dynamic-RON characterization of 600 V GaN switches.",
    "isothermal; operating conditions; blocking voltage; frequency; measurement window",
    "Abstract-level decision only.")

# ---------------- GDR026 ----------------
dec("GDR026", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a steady-state dynamic-RON measurement approach and stabilization-time analysis.",
    "Title: 'Accurate Measurement of Dynamic ON-Resistance in GaN Transistors at Steady-State'.",
    "Abstract: experimental steady-state half-bridge study comparing dynamic RON with pulsed tests and examining stabilization times.",
    "https://doi.org/10.1109/TPEL.2023.3268890", "", "",
    "Yes", "DOI/abstract and author-hosted PDF result visible; full-text screening deferred",
    "Extract steady-state protocol, stabilization-time definitions, and pulsed-vs-steady-state comparison design.",
    "Low: abstract explicitly reports accurate steady-state dynamic-RON measurement on GaN transistors.",
    "steady state; stabilization time; half-bridge; pulsed comparison",
    "Abstract-level decision only.")

# ---------------- GDR027 ----------------
dec("GDR027", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; dynamic-RON and trapping evaluation via pulse schemes is the endpoint.",
    "Title: 'Evaluation of Dynamic On-Resistance and Trapping Effects in GaN on Si HEMTs Using Rectangular Gate Voltage Pulses'.",
    "Abstract: experimental single-pulse, pulse-train, square-wave, and DPT comparisons; explicitly examines pulse timing and current dependence.",
    "https://doi.org/10.3390/electronics14142791", "", "",
    "Yes", "Open-access publisher full text available by page indication; not reviewed",
    "Extract pulse-scheme parameters, timing definitions, and current-dependence findings.",
    "Low: abstract explicitly reports experimental dynamic-RON evaluation with multiple pulse schemes on GaN-on-Si HEMTs.",
    "rectangular gate pulses; single-pulse; pulse-train; square-wave; DPT; pulse timing",
    "Abstract-level decision only.")

# ---------------- GDR028 ----------------
dec("GDR028", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; SiN-passivation effect on dynamic-RON degradation is the endpoint.",
    "Title: 'Impact of SiN Passivation on Dynamic-RON Degradation of 100 V p-GaN Gate AlGaN/GaN HEMTs'.",
    "Abstract: experimental dynamic-RON transient comparison across passivation samples and resistive/soft-switching trajectories, including temperature.",
    "https://doi.org/10.3390/electronicmat6040014", "", "",
    "Yes", "Open-access publisher page surfaced; full text not reviewed",
    "Extract passivation comparison design, switching trajectories, and temperature conditions.",
    "Low: abstract explicitly reports experimental dynamic-RON transient comparison on p-GaN AlGaN/GaN HEMTs.",
    "SiN passivation; p-GaN gate; soft switching; temperature",
    "Abstract-level decision only.")

# ---------------- GDR029 Review ----------------
dec("GDR029", "Review", "Contextual", "Yes", "No", "Unclear",
    "Not applicable: review article, not a primary empirical or measurement-method contribution.",
    "Title: 'Dynamic On-Resistance in GaN Power Devices: Mechanisms, Characterizations and Modeling'.",
    "Abstract: review of dynamic-RON mechanisms, characterization, modeling, and mitigation.",
    "https://doi.org/10.1109/JESTPE.2019.2925117", "", "",
    "No", "Metadata/abstract visible; full text not reviewed",
    "If retained for background: use for terminology, mechanism taxonomy, and citation chaining only; no primary-data extraction.",
    "None: classification as Review is unambiguous.",
    "mechanisms; characterization; modelling; mitigation",
    "Contextual use label: review/background. Not part of the primary empirical evidence set.")

# ---------------- GDR030 Review (authors unverified) ----------------
dec("GDR030", "Review", "Contextual", "Yes", "No", "Unclear",
    "Not applicable: review article, not a primary empirical or measurement-method contribution.",
    "Title: 'A Review of GaN HEMT Dynamic ON-Resistance and Dynamic Stress Effects on Field Distribution'.",
    "Abstract: review of prior dynamic-RON research, measurement limitations, and dynamic stress effects.",
    "https://doi.org/10.1109/TPEL.2023.3318182", "", "",
    "No", "DOI/title metadata visible; full text not available in retrieved result",
    "If retained for background: use for measurement-limitation discussion; no primary-data extraction.",
    "None on category; metadata uncertainty noted (author list unverified).",
    "dynamic stress; field distribution; measurement limitations",
    "Stage 1A metadata caution: author list not verified; retained pending verification. Contextual use label: review/background.")

# ---------------- GDR031 Review ----------------
dec("GDR031", "Review", "Contextual", "Yes", "No", "Unclear",
    "Not applicable: review article, not a primary empirical or measurement-method contribution.",
    "Title: 'Physics and Improvement of Dynamic RON in GaN Power HEMTs: A Comprehensive Review'.",
    "Abstract: review of physics, mechanisms, characterization, and improvement of dynamic RON in GaN power HEMTs.",
    "https://www.sciencedirect.com/science/article/pii/S2773012326002529", "", "",
    "No", "ScienceDirect publisher page; full text not screened",
    "If retained for background: use for physics taxonomy; no primary-data extraction.",
    "None: classification as Review verified against publisher record and Crossref.",
    "physics; mechanisms; improvement strategies",
    "Contextual use label: review/background.")

# ---------------- GDR032 Standard ----------------
dec("GDR032", "Standard / Guideline", "Contextual", "Unclear", "No", "No",
    "Applicable as parameter-category reference for comparing reported measurement conditions; not an empirical study.",
    "Title: 'IEC 63373:2022 - Dynamic on-resistance test method guidelines for GaN HEMT based power conversion devices'.",
    "IEC catalog entry: standardized test-method guideline; contextual/methodological source, not an experimental study. Standard full text not accessed; no compliance claim made.",
    "https://webstore.iec.ch/en/publication/68515", "", "",
    "No", "IEC catalog metadata visible; standard full text not accessed",
    "If used for reporting-completeness assessment: access the official standard text and cite exact clauses; until then no clause-level comparison.",
    "None on category; standard text access unresolved.",
    "standardized test method; parameter categories",
    "Contextual use label: standard/guideline. No IEC compliance testing performed or claimed.")

# ---------------- GDR033 Standard ----------------
dec("GDR033", "Standard / Guideline", "Contextual", "Unclear", "No", "No",
    "Applicable as parameter-category reference for comparing reported measurement conditions; not an empirical study.",
    "Title: 'JEDEC JEP 173 - Dynamic ON-Resistance Test Method Guidelines for GaN HEMT based Power Conversion Devices'.",
    "JEDEC guideline catalog entry: guideline for dynamic on-resistance testing of GaN HEMT power conversion devices. Official JEDEC page/full text not accessed; no compliance claim made.",
    "https://standards.globalspec.com/std/13163346/jedec-jep-173", "", "",
    "No", "Catalog entry visible; official JEDEC page/full text not accessed",
    "If used for reporting-completeness assessment: access the official guideline text and cite exact clauses; until then no clause-level comparison.",
    "None on category; guideline text access unresolved; catalog URL is a third-party aggregator, official JEDEC page should be rechecked.",
    "test guideline; parameter categories",
    "Contextual use label: standard/guideline. No JEDEC compliance testing performed or claimed. Metadata issue logged in issues file (third-party catalog URL).")

# ---------------- GDR034 ----------------
dec("GDR034", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; gate-field-plate suppression of dynamic-RON degradation is the endpoint.",
    "Title: 'Dynamic RON Degradation Suppression by Gate Field Plate in Partially Recessed AlGaN/GaN MIS-HEMTs'.",
    "Abstract: experimental investigation of gate field-plate length and dynamic on-resistance degradation in partially recessed-gate D-mode GaN MIS-HEMTs; gate field plates suppress trapping-related degradation.",
    "https://onlinelibrary.wiley.com/doi/10.1002/pssa.202300976", "", "",
    "Yes", "Publisher page/metadata accessed; full-text screening not performed",
    "Extract field-plate geometry variants, trapping evidence, and dynamic-RON measurement protocol.",
    "Low: abstract explicitly reports experimental dynamic-RON degradation investigation with device-structure comparison.",
    "gate field plate; partially recessed MIS-HEMT; D-mode; trapping",
    "Abstract-level decision only.")

# ---------------- GDR035 (verified via OpenAlex) ----------------
dec("GDR035", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper per Stage 1 classification; the setup enables dynamic-RON characterization and dynamic-RON degradation is the endpoint.",
    "Title: 'On-Wafer Dynamic Operation of Power GaN-HEMTs: Degradation Processes Investigated by a Novel Experimental Approach'.",
    "Publisher abstract (OpenAlex reconstruction of the IEEE IRPS 2024 record): presents an on-wafer D-HTOL and dynamic RON characterization setup, validated by analyzing dynamic behavior of 650 V p-GaN-gate HEMTs in hard switching; attributes dynamic RON degradation to carbon-doped-buffer and surface trapping.",
    "https://ieeexplore.ieee.org/document/10529407/", "", "",
    "Yes", "IEEE publisher page/metadata accessed; abstract additionally reconstructed from OpenAlex record 2026-11-17; full text not screened",
    "Extract on-wafer stress parameters, hard-switching tuning range, and trapping-attribution evidence.",
    "Low: abstract explicitly reports dynamic RON characterization and degradation on p-GaN HEMTs.",
    "on-wafer; D-HTOL; hard switching; buffer/surface trapping",
    "Direct dynamic-RON evidence confirmed from the published abstract (OpenAlex reconstruction of the IEEE record); full text not screened.")

# ---------------- GDR036 ----------------
dec("GDR036", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; hysteresis/charge-trapping evaluation with dynamic-RON response is the endpoint.",
    "Title: 'Using Triangular Gate Voltage Pulses to Evaluate Hysteresis and Charge Trapping Effects in GaN on Si HEMTs'.",
    "Abstract: uses triangular gate-voltage pulses to measure hysteresis and charge trapping in GaN-on-Si HEMTs; includes threshold-voltage and dynamic-RON response following stress.",
    "https://www.mdpi.com/2079-9292/14/10/1991", "", "",
    "Yes", "Publisher page/metadata accessed; full-text screening not performed",
    "Extract triangular-pulse protocol, hysteresis quantification, and dynamic-RON response conditions.",
    "Low: abstract explicitly reports dynamic-RON response measurement following stress on GaN-on-Si HEMTs.",
    "triangular gate pulses; hysteresis; charge trapping; threshold voltage",
    "Abstract-level decision only.")

# ---------------- GDR037 ----------------
dec("GDR037", "Experimental Measurement Method / Instrumentation / Protocol", "Include", "Yes", "Yes", "Yes",
    "Direct: principal contribution is a time-resolved steady-state dynamic-RON measurement methodology across microseconds to minutes.",
    "Title: 'Steady-State Dynamic RON Measurements of GaN HEMTs: Role of Voltage- and Temperature-Dependent Time Constants'.",
    "Abstract: proposes time-resolved steady-state dynamic RON measurements from microseconds to minutes and evaluates voltage and temperature dependence of trapping time constants in p-GaN HEMTs.",
    "https://ieeexplore.ieee.org/document/11524101", "", "",
    "Yes", "IEEE publisher page/abstract accessed; full-text screening not performed",
    "Extract time-resolved protocol, time-constant extraction method, and reporting completeness.",
    "Low: abstract explicitly reports a steady-state dynamic-RON measurement methodology with p-GaN HEMT data.",
    "steady state; time-resolved; time constants; voltage/temperature dependence",
    "Abstract-level decision only.")

# ---------------- GDR038 ----------------
dec("GDR038", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; trap-state contributions to dynamic-RON degradation is the endpoint.",
    "Title: 'Comprehensive study of dynamic on-resistance in AlGaN/GaN MIS-HEMTs with partially recessed-gate'.",
    "Abstract: compares recessed and non-recessed AlGaN/GaN MIS-HEMTs and investigates trap-state contributions to dynamic RON degradation under high-drain-bias switching-relevant conditions.",
    "https://www.sciencedirect.com/science/article/abs/pii/S0038110126000535", "", "",
    "Yes", "ScienceDirect publisher page/abstract accessed; full-text screening not performed",
    "Extract recessed vs non-recessed comparison design, trap-location analysis, and measurement protocol.",
    "Low: abstract explicitly reports experimental dynamic-RON degradation study with device-structure comparison.",
    "partially recessed MIS-HEMT; trap locations; high-drain-bias stress",
    "Abstract-level decision only.")

# ---------------- GDR039 (flagged) ----------------
dec("GDR039", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper per Stage 1 classification; static and dynamic on-resistance characterization at 77 K is the endpoint.",
    "Title: 'Impact of Charge Carrier Trapping on GaN-HEMT Characteristics at Cryogenic Temperatures'.",
    "KITopen abstract reports static and dynamic on-resistance characterization of commercial GaN HEMTs at 77 K using an extended modified double-pulse test, with charge-carrier trapping analysis.",
    "https://publikationen.bibliothek.kit.edu/1000199117", "", "",
    "Yes", "KITopen institutional repository page and PDF link available; no full-text screening (Stage 1A flag)",
    "Extract cryogenic DPT parameters, 77 K setup details, and trapping analysis at full text.",
    "Low on abstract evidence (Stage 1A-verified KITopen abstract); medium pending full text; publication-DOI registry validation remains unresolved (repository DOI/identifier distinct).",
    "cryogenic; 77 K; DPT; charge trapping",
    "Handoff-flagged record: abstract-supported candidate pending full text. Publication DOI 10.30420/566716362 distinguished from repository DOI 10.5445/IR/1000199117 and KITopen-ID 1000199117.")

# ---------------- GDR040 ----------------
dec("GDR040", "Mechanism Study with Direct Dynamic-RON Evidence", "Include", "Yes", "Yes", "Yes",
    "Not a method paper; gate-trapping-induced dynamic-RON degradation is the endpoint (includes TCAD support only).",
    "Title: 'Gate Trapping-Induced Dynamic Ron Degradation in p-GaN Power HEMTs under Continuous Hard Switching Conditions'.",
    "Abstract: studies gate-trapping-induced dynamic RON degradation in 650 V p-GaN power HEMTs under pulsed off-state stress and continuous hard switching; includes device measurements and TCAD analysis.",
    "https://ieeexplore.ieee.org/document/11499226/", "", "",
    "Yes", "IEEE publisher page/abstract accessed; full-text screening not performed",
    "Extract continuous-hard-switching conditions, pulsed off-state stress parameters, and measurement protocol.",
    "Low: abstract explicitly reports experimental dynamic-RON degradation measurements on 650 V p-GaN HEMTs; TCAD is supporting, not the sole contribution.",
    "gate trapping; continuous hard switching; pulsed off-state stress; TCAD support",
    "Abstract-level decision only.")

def main():
    bib = load_bib()
    ids_bib = sorted(bib.keys())
    assert len(ids_bib) == 40, f"bibliography has {len(ids_bib)} records"
    missing = [i for i in ids_bib if i not in D]
    extra = [i for i in D if i not in bib]
    assert not missing, f"no decision for: {missing}"
    assert not extra, f"decision for unknown id: {extra}"

    cols = ["Report_ID","Title","Year","Document_Type","Primary_Category_Stage1","Study_Relevance_Class",
            "Screening_Decision","Exclusion_Reason_Code","Decision_Rationale","GaN_HEMT_Confirmed",
            "Experimental_Data_Confirmed","Direct_Dynamic_RON_Evidence","Measurement_Method_Relevance",
            "Title_Evidence","Abstract_Evidence","Evidence_Source_URL","Report_Family_ID",
            "Family_Relationship_Note","Full_Text_Required","Full_Text_Access_Status_As_Known",
            "Full_Text_Checkpoints","Screening_Uncertainty","Secondary_Topic_Tags","Reviewer_Notes"]

    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, "Stage2_Title_Abstract_Screening.csv")
    counts = {}
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
        w.writerow(cols)
        for i in ids_bib:
            b, d = bib[i], D[i]
            rationale = (
                f"Decision {d['Screening_Decision']} based on title/abstract evidence only. "
                + d["Abstract_Evidence"]
                + (" Exclusion code: " + d["Exclusion_Reason_Code"] if d["Exclusion_Reason_Code"] else "")
            )
            w.writerow([i, b["Title"], b["Year"], b["Document_Type"], b["Primary_Category"],
                        d["Study_Relevance_Class"], d["Screening_Decision"], d["Exclusion_Reason_Code"],
                        rationale, d["GaN_HEMT_Confirmed"], d["Experimental_Data_Confirmed"],
                        d["Direct_Dynamic_RON_Evidence"], d["Measurement_Method_Relevance"],
                        d["Title_Evidence"], d["Abstract_Evidence"], d["Evidence_Source_URL"],
                        d["Report_Family_ID"], d["Family_Relationship_Note"], d["Full_Text_Required"],
                        b["Full_Text_Access"], d["Full_Text_Checkpoints"], d["Screening_Uncertainty"],
                        d["Secondary_Topic_Tags"], d["Reviewer_Notes"]])
            counts[d["Screening_Decision"]] = counts.get(d["Screening_Decision"], 0) + 1
    print("rows:", len(ids_bib))
    print("decisions:", counts)

if __name__ == "__main__":
    main()
