# -*- coding: utf-8 -*-
"""Build Output 3 (retrieval queue) and Output 5 (metadata/evidence issues CSV)."""
import csv, os
from _screening_data import load_bib, OUT

bib = load_bib()

queue_cols = ["Report_ID","Title","Year","DOI","Publisher_or_Repository_URL","Retrieval_Reason",
              "Full_Text_Access_Status_As_Known","Key_Questions_To_Resolve","Report_Family_Flag"]
issues_cols = ["Issue_ID","Report_ID","Field_Or_Aspect","Original_Value_As_Supplied","Issue_Description",
               "Evidence_Or_Source","Proposed_Action","Confidence","Stage2_Date"]
issues = [
 ["ISS01","GDR014","Authors","Y. Li et al. (full author list not verified in accessible result)",
  "Full author list unverified at Stage 1A; unchanged in Stage 2; title/abstract-level screening proceeded but metadata completeness pending.",
  "Stage 1A bibliography Metadata_Verification_Status; no publisher author page consulted in Stage 2",
  "Verify author list at full-text retrieval from IEEE Xplore/Crossref; do not edit Stage 1A files.","High","2026-11-17"],
 ["ISS02","GDR020","Authors","A. Barbato et al. (full author list not verified in accessible result)",
  "Full author list unverified at Stage 1A; unchanged in Stage 2.",
  "Stage 1A bibliography Metadata_Verification_Status",
  "Verify author list at full-text retrieval from IET Digital Library/Crossref.","High","2026-11-17"],
 ["ISS03","GDR021","Authors","P. J. Martinez et al. (full author list not checked in this run)",
  "Full author list unverified at Stage 1A; unchanged in Stage 2.",
  "Stage 1A bibliography Metadata_Verification_Status",
  "Verify author list at full-text retrieval from MDPI; also cross-check against GDR024 author list for RF04.","High","2026-11-17"],
 ["ISS04","GDR024","Authors","P. J. Martinez et al. (full author list not verified in this run)",
  "Full author list unverified at Stage 1A; unchanged in Stage 2.",
  "Stage 1A bibliography Metadata_Verification_Status",
  "Verify author list at full-text retrieval from MDPI; also cross-check against GDR021 author list for RF04.","High","2026-11-17"],
 ["ISS05","GDR030","Authors","Authors not verified from accessible search result",
  "Author list absent/unverified; the only record with no named authors in the bibliography.",
  "Stage 1A bibliography Metadata_Verification_Status",
  "Verify author list from IEEE Xplore at retrieval; record remains Contextual (Review) either way.","High","2026-11-17"],
 ["ISS06","GDR005","Abstract_GaN_Validation","Abstract motivates method by AlGaN/GaN current collapse; validation shown on a 2-MHz inverted buck converter without naming transistor technology",
  "Abstract does not establish that the validated measurement devices were GaN HEMTs; record screened as Unclear rather than Include.",
  "OpenAlex reconstruction of IEEE TIE record 6880783 (consulted 2026-11-17); IEEE Xplore page text not retrievable by automated fetch",
  "At full text: identify validation transistor technology and whether GaN dynamic-RON data are reported.","Medium","2026-11-17"],
 ["ISS07","GDR033","Evidence_Source_URL","https://standards.globalspec.com/std/13163346/jedec-jep-173",
  "Source URL is a third-party standards aggregator, not the official JEDEC catalog page; official JEDEC page/full text not accessed.",
  "Stage 1A bibliography Full_Text_Access note",
  "At retrieval: locate the official JEDEC JEP 173 catalog record and replace/annotate the URL; no Stage 1A file edits.","High","2026-11-17"],
 ["ISS08","GDR039","DOI_registry_validation","Publication DOI 10.30420/566716362 not independently resolved in DOI registry (Crossref) per Stage 1A",
  "KITopen labels 10.30420/566716362 as the publication DOI, but independent registry resolution remained unresolved; repository DOI 10.5445/IR/1000199117 and KITopen-ID 1000199117 are distinct.",
  "Stage 1A DOI verification notes; KITopen record https://publikationen.bibliothek.kit.edu/1000199117",
  "Keep the three identifiers distinct; re-attempt registry resolution at full-text retrieval.","Medium","2026-11-17"],
]

def main():
    with open("Stage2_Title_Abstract_Screening.csv", encoding="utf-8-sig") as f:
        scr = list(csv.DictReader(f))

    q = [r for r in scr if r["Screening_Decision"] in ("Include", "Unclear")]
    with open("Stage2_Full_Text_Retrieval_Queue.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
        w.writerow(queue_cols)
        for r in q:
            b = bib[r["Report_ID"]]
            reason = ("Screening_Decision=Include: abstract-level evidence supports GaN HEMT dynamic-RON experimental/measurement-method record; "
                      "full text needed to verify protocol details and reporting completeness."
                      if r["Screening_Decision"] == "Include" else
                      "Screening_Decision=Unclear: abstract does not establish GaN HEMT validation (GDR005); full text needed to determine inclusion.")
            w.writerow([r["Report_ID"], r["Title"], r["Year"], b["DOI"], b["Publisher_URL"], reason,
                        r["Full_Text_Access_Status_As_Known"], r["Full_Text_Checkpoints"],
                        r["Report_Family_ID"] or "None"])
    with open("Stage2_Metadata_or_Evidence_Issues.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
        w.writerow(issues_cols)
        w.writerows(issues)
    print("queue rows:", len(q), "issue rows:", len(issues))

if __name__ == "__main__":
    main()
